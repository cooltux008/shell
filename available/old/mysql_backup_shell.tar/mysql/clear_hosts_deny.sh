#!/bin/bash
#To clear "/etc/hosts.deny" for a long time
#2012/04/07

###############################################################



#recover the "/etc/hosts.deny" to default

grep '^#' /etc/hosts.deny|tee /etc/hosts.deny >/dev/null 2>&1




#restart the ssh server

/etc/init.d/sshd restart
