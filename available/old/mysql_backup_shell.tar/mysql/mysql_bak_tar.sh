#!/bin/bash
#To dump mysql weekly
#2012/04/08
###################################################

#判断是否已有全备,若没有则创建
if [ ! -f /backup/mysql_all*.tar.lzma ];then
	tar -cvpPf /backup/mysql_all$(date +%Y-%m-%d-%H\:%M\:%S).tar.lzma  --lzma -g /backup/mysql.snar /var/mysql/*
fi

#增量备份
if [ -f /backup/mysql_all*.tar.lzma ];then
	
	#查看备份数据库
	if [ -f "bkdb" ]; then
		eval $(grep VER bkdb)
		eval $(grep NAME bkdb)
		OLD=$VER
		NEW=$((OLD+1)) 
		NAME=$NAME

		else NEW=0
	fi
#定义备份时的运行环境
export LANG=C
export BKFILE_DAY=$(date +%Y-%m-%d)
export BKFILE_WEEK=$(date +%a)

export DATA_BKFILE_DAY=${BKFILE_DAY}-${NEW}.tar.lzma
export OLDSNAP=${NAME}.snar
export NEWSNAP=${BKFILE_DAY}-${NEW}.snar

	
	if [ $BKFILE_WEEK != "Sun" ];then
		#更新snar文件
		if [ -f mysql.snar ];then
			mv /backup/mysql.snar /backup/${NAME}.snar 
		fi

		if [ -e "$OLDSNAP" ]; then
		cp $OLDSNAP $NEWSNAP
		tar -cvpPf /backup/${DATA_BKFILE_DAY} --lzma -g /backup/$NEWSNAP  /var/mysql
		echo VER=${NEW} > bkdb
		echo NAME=${BKFILE_DAY}-${NEW} >> bkdb
		fi
	fi

	if [ $BKFILE_WEEK = "Sun" ];then
		mkdir /backup/tmp
		tar -xvpPGf /backup/mysql_all*.tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="6 days ago" +%Y-%m-%d)-$(($NEW-5)).tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="5 days ago" +%Y-%m-%d)-$(($NEW-4)).tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="4 days ago" +%Y-%m-%d)-$(($NEW-3)).tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="3 days ago" +%Y-%m-%d)-$(($NEW-2)).tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="2 days ago" +%Y-%m-%d)-$(($NEW-1)).tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		tar -xvpPGf /backup/$(date --date="1 days ago" +%Y-%m-%d)-$NEW.tar.lzma --lzma -g /backup/$NEWSNAP -C /backup/tmp
		
		rm -rf /backup/*.tar.lzma >/dev/null 2>&1
		rm -rf /backup/*.snar >/dev/null 2>&1
		tar -cvpPf /backup/mysql_all$(date +%Y-%m-%d-%H\:%M\:%S).tar.lzma  --lzma -g /backup/mysql.snar  /backup/tmp/* 
		rm -rf /backup/tmp >/dev/null 2>&1 
	fi
fi
