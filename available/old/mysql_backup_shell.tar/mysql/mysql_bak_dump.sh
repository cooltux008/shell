#!/bin/bash
#To dump mysql by dump & restore
#2012/04/08
##################################################################################


#backup recent 7 days
if [ ! -e /var/backup/mysql/mysql.dump.1 ];then
	dump -1u -f /var/backup/mysql/mysql.dump.1 /var
		elif [ ! -e /var/backup/mysql/mysql.dump.2 ];then
			dump -2u -f /var/backup/mysql/mysql.dump.2 /var
			elif [ ! -e /var/backup/mysql/mysql.dump.3 ];then
				dump -3u -f /var/backup/mysql/mysql.dump.3 /var
				elif [ ! -e /var/backup/mysql/mysql.dump.4 ];then
					dump -4u -f /var/backup/mysql/mysql.dump.4 /var
					elif [ ! -e /var/backup/mysql/mysql.dump.5 ];then
						dump -5u -f /var/backup/mysql/mysql.dump.5 /var
						elif [ ! -e /var/backup/mysql/mysql.dump.6 ];then
							dump -6u -f /var/backup/mysql/mysql.dump.6 /var
							elif [ ! -e /var/backup/mysql/mysql.dump.7 ];then
								dump -7u -f /var/backup/mysql/mysql.dump.7 /var
fi


#restore recent 7 days
if [ -e /var/backup/mysql.dump.7 ];then
	cd /mnt/backup/mysql
	restore -r -f /mnt/backup/mysql/mysql.dump 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.1 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.2 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.3 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.4 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.5 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.6 
	restore -r -f /var/mysql/backup/mysql/mysql.dump.7 

	rm -rf /var/backup/mysql/*
	rm -rf /mnt/backup/msyql/*.dump

#dump once again
	dump -0u -f /mnt/backup/mysql/mysql.dump  /mnt/backup/mysql/
fi
