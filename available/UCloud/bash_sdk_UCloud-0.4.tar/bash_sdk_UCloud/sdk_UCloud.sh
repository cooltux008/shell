####################################################
#!/bin/env bash
#To call UCloud API with shell
#Made by liujun,jlive.liu@ucloud.cn,2015-04-13
####################################################
#reload common arguments
common_conf=$PWD/common.conf
if [ ! -f "$common_conf" ];then
        echo -e "\e[31;1m$common_conf\e[0m \e[34;1mis not exsit\e[0m"
	exit 1
fi
source $common_conf

#useage format
if [ $# -ne 1 ];then
        echo -e "\e[34;1mUsage\e[0m: \e[32;1m$0\e[0m \e[31;1margs.conf\e[0m"
	exit 1
fi
if [ ! -f "$1" ];then
        echo -e "\e[31;1m$1\e[0m \e[34;1mis not exsit\e[0m"
	exit 1
fi
valid_conf_flag=$(grep -w Action $1)
if [ "$valid_conf_flag" == "" ];then
        echo -e "\e[31;1m$1\e[0m \e[34;1mis invalid\e[0m"
	exit 1
fi


#action
api_tmp_file=/tmp/api_tmp.conf
cat $1|grep -v ^$|grep -v ^#|sed 's/"//g'|sed "s/'//g" 2>/dev/null >$api_tmp_file && echo PublicKey="$public_key" >>$api_tmp_file

#signature
signature_tmp=$(echo -n $(cat $api_tmp_file|sort -V|tr -d '"'|tr -d '='|xargs|tr -d ' ' && echo -n $private_key)|tr -d ' ')
signature=$(echo -n $signature_tmp|sha1sum)

#https_api
api_http_1=$(echo $base_url/?$(echo Signature=$signature))
api_http_2=$(cat /tmp/api_tmp.conf|sort|tr -d '"'|sed 's/@/%40/g'|sed 's/|/%7C/g'|sed 's/^/\&/g'|xargs -n3|tr -d ' ')
api_http=$(echo $(echo $api_http_1|sed 's/-//g') $api_http_2|xargs|tr -d ' ')

#call api
elinks_flag=$(which elinks 2>&1|grep -w no)
if [ "$elinks_flag" != "" ];then
	echo -e "You need to install \e[31;1melinks\e[0m first"
	exit 1
fi

echo -e "\e[31;1mWait\e[0m ..."
sleep .3
echo -e "\e[31;1m----------------------------------------------------------\e[0m"
elinks -dump $api_http
echo -e "\e[31;1m----------------------------------------------------------\e[0m"
echo -e "\e[32;1mDone\e[0m"
